<?php

require 'config.php';
include 'methods/crud.php';
include 'methods/pagination.php';
include 'methods/search_data.php';
include 'methods/table.php';
include 'methods/login.php';
include 'methods/function.php';
include 'ajax/method.js';
